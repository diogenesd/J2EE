package test;

import java.sql.SQLException;
import java.util.List;

import org.junit.Test;

import br.com.livro.domain.Carro;
import br.com.livro.domain.CarroService;
import junit.framework.TestCase;

public class CarroTest extends TestCase {
	
	private CarroService carroService = new CarroService();
	@Test
	public void test() {
		try {
			//testListaCarro();
			//testSalvarDeletarCarro();
			testDeletarCarro();
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	@Test
	public void testListaCarro() throws SQLException{
		
		List<Carro> carros = carroService.getCarros();
		assertNotNull(carros);
		// Valida se encontrou algo
		assertTrue(carros.size()>0);
		//Valida de encontrou o Trucker
		Carro trucker = carroService.findByName("Tucker 1948").get(0);
		assertEquals("Tucker 1948", trucker.getNome());
		//Valida se encontrou o Ferrari
		Carro ferrari = carroService.findByName("Ferrari FF").get(0);
		assertEquals("Ferrari FF", ferrari.getNome());
		//Valida se encontrou o Bugatti
		Carro bugatti = carroService.findByName("Bugatti Veyron").get(0);
		assertEquals("Bugatti Veyron", bugatti.getNome());
	}
	
	@Test
	public void testSalvarDeletarCarro() throws SQLException{
		Carro c = new Carro();
		c.setNome("Test");
		c.setDesc("Test Desc");
		c.setUrlFoto("url foto aqui");
		c.setUrlVideo("url video aqui");
		c.setLatitude("lat");
		c.setLongitude("lng");
		c.setTipo("tipo");
		carroService.save(c);
		//Id do carro salvo
		Long id = c.getId();
		assertNotNull(id);
		
		//Busca no database para confirmar que o carro foi salvo
		c = carroService.getCarro(id);
		assertEquals("Test", c.getNome());
		assertEquals("Test Desc", c.getDesc());
		assertEquals("url foto aqui", c.getUrlFoto());
		assertEquals("url video aqui", c.getUrlVideo());
		assertEquals("lat", c.getLatitude());
		assertEquals("lng", c.getLongitude());
		assertEquals("tipo", c.getTipo());
		
		//Atualiza o carro
		c.setNome("Test UPDATE");
		carroService.save(c);
		
		//Busca o carro novamente (vai estar atulaizado)
		c = carroService.getCarro(id);
		assertEquals("Test UPDATE", c.getNome());
		
		//Deletar carro
		carroService.delete(id);
		
		//Buscar carro novamente (N�o existe mais)
		c = carroService.getCarro(id);
		assertNull(c);
		
	}
	
	@Test
	public void testDeletarCarro() throws SQLException{
		
		Long id = new Long(34);
		assertTrue(carroService.delete(id));
	}

}
