package br.com.livro.rest;

import java.sql.SQLException;
import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import br.com.livro.domain.Carro;
import br.com.livro.domain.CarroService;
import br.com.livro.domain.Response;

@Path("/carros")
@Consumes(MediaType.APPLICATION_JSON + ";charset=utf-8")
@Produces(MediaType.APPLICATION_JSON + ";charset=utf-8")
public class CarroResource {

	private CarroService carroService = new CarroService();

	@GET
	public List<Carro> get() {
		return carroService.getCarros();
	}

	@GET
	@Path("{id}")
	public Carro get(@PathParam(Carro.ID) long id) throws SQLException {
		return carroService.getCarro(id);
	}

	@GET
	@Path("/tipo/{tipo}")
	public List<Carro> getByType(@PathParam(Carro.TIPO) String tipo) throws SQLException {
		return carroService.findByType(tipo);
	}

	@GET
	@Path("/nome/{nome}")
	public List<Carro> getByName(@PathParam(Carro.NOME) String nome) throws SQLException {
		return carroService.findByName(nome);
	}

	@DELETE
	@Path("{id}")
	public Response delete(@PathParam(Carro.ID) long id) throws SQLException {
		boolean ret = carroService.delete(id);
		return ret?Response.OK("Carro deletado com sucesso!"):
			Response.Error("Carro n�o encontrado");
	}
	
	@POST
	public Response post(Carro c) throws SQLException{
		boolean ret = carroService.save(c);
		return ret?Response.OK("Carro inserido com sucesso!"):
			Response.Error("Carro n�o foi possivel inserir o carro");
		
	}
	
	@PUT
	public Response put(Carro c) throws SQLException{
		boolean ret = carroService.save(c);
		return ret?Response.OK("Carro atualizado com sucesso!"):
			Response.Error("Carro n�o foi possivel atualizar o carro");
		
	}
	
	
}
