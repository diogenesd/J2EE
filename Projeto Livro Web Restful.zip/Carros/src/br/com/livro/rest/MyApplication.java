package br.com.livro.rest;

import java.util.HashMap;
import java.util.Map;

import javax.ws.rs.core.Application;

public class MyApplication extends Application{
	
	// Desativado este metodo pois passamos a usar a lib Gson
	/*@Override
	public Set<Object> getSingletons() {
		Set<Object> singletons = new HashSet<>();
		//Driver para o Jettison para gerar JSON
		singletons.add(new JettisonFeature());
		return singletons;
	}*/
	
	@Override
	public Map<String, Object> getProperties() {
		Map<String, Object> properties = new HashMap<>();
		// Configura o pacote para fazer o scan das classes com anota��es REST
		properties.put("jersey.config.server.provider.packages", "br.com.livro");
		return properties;
	}
}
