package br.com.livro.domain;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class CarroDAO extends BaseDAO {

	/**
	 * @param id Inserir o ID (tipo Long) do carro de deseja buscar no database.
	 * @return Retorna o objeto do carro encontrado pelo paramentro ou nulo caso
	 *         n�o encontre.
	 * @throws SQLException
	 */
	public Carro getCarroById(Long id) throws SQLException {
		Connection conn = null;
		PreparedStatement pstmt = null;
		String sql = "select * from carro where id=?";

		try {
			conn = getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setLong(1, id);
			ResultSet rs = pstmt.executeQuery();
			if (rs.next()) {
				Carro c = createCarro(rs);
				rs.close();
				return c;
			}
		} finally {
			if (pstmt != null)
				pstmt.close();
			if (conn != null)
				conn.close();
		}
		return null;
	}

	/**
	 * @param name Inserir o nome (tipo String) do carro de deseja buscar no database.
	 * @return Retorna uma lista com os objetos de carros encontrado pelo
	 *         paramentro ou uma lista vazia caso n�o encontre.
	 * @throws SQLException
	 */
	public List<Carro> findByName(String name) throws SQLException {

		List<Carro> carros = new ArrayList<Carro>();
		Connection conn = null;
		PreparedStatement pstmt = null;
		String sql = "select * from carro where lower(nome) like ?";

		try {
			conn = getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, "%" + name.toLowerCase() + "%");
			ResultSet rs = pstmt.executeQuery();
			while (rs.next()) {
				Carro c = createCarro(rs);
				carros.add(c);
			}
			rs.close();

		} finally {
			if (pstmt != null)
				pstmt.close();
			if (conn != null)
				conn.close();
		}
		return carros;
	}

	/**
	 * @param type Inserir o tipo (tipo String) do carro de deseja buscar no database.
	 * @return Retorna uma lista com os objetos de carros encontrado pelo
	 *         paramentro ou uma lista vazia caso n�o encontre.
	 * @throws SQLException
	 */
	public List<Carro> findByType(String type) throws SQLException {

		List<Carro> carros = new ArrayList<Carro>();
		Connection conn = null;
		PreparedStatement pstmt = null;
		String sql = "select * from carro where tipo = ?";

		try {
			conn = getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, type);
			ResultSet rs = pstmt.executeQuery();
			while (rs.next()) {
				Carro c = createCarro(rs);
				carros.add(c);
			}
			rs.close();

		} finally {
			if (pstmt != null)
				pstmt.close();
			if (conn != null)
				conn.close();
		}
		return carros;
	}

	/**
	 * @return Retorna uma lista com todos os carros encontrados no database, ou
	 *          uma lista vazia caso n�o gera algum erro.
	 * @throws SQLException
	 */
	public List<Carro> getCarros() throws SQLException {

		List<Carro> carros = new ArrayList<Carro>();
		Connection conn = null;
		PreparedStatement pstmt = null;
		String sql = "select * from carro";

		try {
			conn = getConnection();
			pstmt = conn.prepareStatement(sql);
			ResultSet rs = pstmt.executeQuery();
			while (rs.next()) {
				Carro c = createCarro(rs);
				carros.add(c);
			}
			rs.close();

		} finally {
			if (pstmt != null)
				pstmt.close();
			if (conn != null)
				conn.close();
		}
		return carros;
	}

	/**
	 * @param Inserir um obejto ResultSet criar o objeto carro com o retorno do database;
	 * @return Um objeto carro criado a partir do retorno do database
	 * @throws SQLException
	 */
	public Carro createCarro(ResultSet rs) throws SQLException {

		Carro c = new Carro();
		c.setId(rs.getLong(Carro.ID));
		c.setNome(rs.getString(Carro.NOME));
		c.setDesc(rs.getString(Carro.DESC));
		c.setUrlFoto(rs.getString(Carro.URL_FOTO));
		c.setUrlVideo(rs.getString(Carro.URL_VIDEO));
		c.setLatitude(rs.getString(Carro.LATITUDE));
		c.setLongitude(rs.getString(Carro.LONGITUDE));
		c.setTipo(rs.getString(Carro.TIPO));
		return c;

	}

	/**
	 * @param c Iserir um obejto do tipo Carro para ser persistido no database.
	 * @throws SQLException
	 */
	public void save(Carro c) throws SQLException {

		Connection conn = null;
		PreparedStatement pstmt = null;
		String insert = "insert into carro (nome, descricao, url_foto, " + "url_video, latitude, longitude, tipo) "
				+ "VALUES (?,?,?,?,?,?,?)";

		String update = "update carro set nome=?, descricao=?, url_foto=?, "
				+ "url_video=?, latitude=?, longitude=?, tipo=? " + "where id=?";

		try {
			conn = getConnection();

			if (c.getId() == null) {
				pstmt = conn.prepareStatement(insert, Statement.RETURN_GENERATED_KEYS);
			} else {
				pstmt = conn.prepareStatement(update);
			}

			pstmt.setString(1, c.getNome());
			pstmt.setString(2, c.getDesc());
			pstmt.setString(3, c.getUrlFoto());
			pstmt.setString(4, c.getUrlVideo());
			pstmt.setString(5, c.getLatitude());
			pstmt.setString(6, c.getLongitude());
			pstmt.setString(7, c.getTipo());
			if (c.getId() != null)
				pstmt.setLong(8, c.getId());

			int count = pstmt.executeUpdate();
			if (count == 0)
				throw new SQLException("Erro ao inserir o carro");

			if (c.getId() == null) {
				Long id = getGeneratedId(pstmt);
				c.setId(id);
			}

		} finally {
			if (pstmt != null)
				pstmt.close();
			if (conn != null)
				conn.close();
		}
	}

	/**
	 * @param Inserir um PreparedStatement para que seja buscado as Keys geradas no database pelo comando auto-increment.
	 * @return Retorna um obejto do tipo Long que foi gerado automaticamente pelo database.
	 * @throws SQLException
	 */
	public static Long getGeneratedId(PreparedStatement pstmt) throws SQLException {
		ResultSet rs = pstmt.getGeneratedKeys();
		if (rs.next()) {
			Long id = rs.getLong(1);
			return id;
		}
		return 0L;

	}

	/**
	 * @param id Inserir o ID (tipo Long) do carrro que quer deletar do database.
	 * @return Retorna true caso seja deletado algum registro no database ou
	 *         retorna fase caso n�o tenha sido deletado nenhum registro.
	 * @throws SQLException
	 */
	public boolean delete(Long id) throws SQLException {

		Connection conn = null;
		PreparedStatement pstmt = null;
		String sql = "delete from carro where id=?";

		try {
			conn = getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setLong(1, id);
			int count = pstmt.executeUpdate();
			boolean ok = count > 0;
			return ok;

		} finally {
			if (pstmt != null)
				pstmt.close();
			if (conn != null)
				conn.close();
		}

	}

}
