package br.com.livro.domain;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class BaseDAO {

	private Connection conn;
	private String database;
	private String user;
	private String password;
	
	public BaseDAO() {

		try {
			Class.forName("com.mysql.jdbc.Driver");
			this.database = "livro";
			this.user = "livro";
			this.password = "livro123";
			
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
	}
	
	protected Connection getConnection() throws SQLException {
		
		String url = "jdbc:mysql://localhost/"+database;
		/*if(!(this.conn == null))
			return conn;*/
		this.conn = DriverManager.getConnection(url,user,password);
		return conn;
	}
	
	public static void main( String[] args ) throws SQLException {
		BaseDAO db = new BaseDAO();
		Connection conn = db.getConnection();
		System.out.println(conn);
	}
	
	
}
