package br.com.livro.domain;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class CarroService {
	private CarroDAO db = new CarroDAO();

	/**
	 * @return Retorna uma lista com todos os carros encontrados no database, ou
	 *         uma lista vazia caso n�o gera algum erro.
	 * 
	 */
	public List<Carro> getCarros() {
		try {
			List<Carro> carros = db.getCarros();
			return carros;

		} catch (SQLException e) {
			e.printStackTrace();
			return new ArrayList<Carro>();
		}
	}

	/**
	 * @param id Inserir o ID (tipo Long) do carro de deseja buscar no database.
	 * @return Retorna o objeto do carro encontrado pelo paramentro ou nulo caso
	 *         n�o encontre.
	 * @throws SQLException
	 */
	public Carro getCarro(Long id) throws SQLException {
		try {
			return db.getCarroById(id);

		} catch (SQLException e) {
			e.printStackTrace();
			return null;
		}
	}

	/**
	 * @param id Inserir o ID (tipo Long) do carrro que quer deletar do database.
	 * @return Retorna true caso seja deletado algum registro no database ou
	 *         retorna fase caso n�o tenha sido deletado nenhum registro.
	 * @throws SQLException
	 */
	public boolean delete(Long id) throws SQLException {
		try {
			return db.delete(id);

		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		}

	}

	/**
	 * @param carro Iserir um obejto do tipo Carro para ser persistido no database.
	 * @return Retorna true caso tenha salvo o objeto Carro com sucesso no
	 *         database ou false caso n�o tenha conseguido salvar.
	 * @throws SQLException
	 */
	public boolean save(Carro carro) throws SQLException {
		try {
			db.save(carro);
			return true;

		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		}
	}
	
	/**
	 * @param name Inserir o nome (tipo String) do carro de deseja buscar no database.
	 * @return Retorna uma lista com os objetos de carros encontrado pelo
	 *         paramentro ou nulo caso n�o encontre.
	 * @throws SQLException
	 */
	public List<Carro> findByName(String name) throws SQLException{
		try {
			return db.findByName(name);

		} catch (SQLException e) {
			e.printStackTrace();
			return null;
		}
		
	}
	
	/**
	 * @param type Inserir o tipo (tipo String) do carro de deseja buscar no database.
	 * @return Retorna uma lista com os objetos de carros encontrado pelo
	 *         paramentro ou nulo n�o encontre.
	 * @throws SQLException
	 */
	public List<Carro> findByType(String type) throws SQLException{
		try {
			return db.findByType(type);

		} catch (SQLException e) {
			e.printStackTrace();
			return null;
		}
	}
}
