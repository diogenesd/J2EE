package br.com.livro.servelets;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import br.com.livro.domain.Carro;
import br.com.livro.domain.CarroService;
import br.com.livro.domain.ListaCarros;
import br.com.livro.domain.Response;
import br.com.livro.util.RegexUtil;
import br.com.livro.util.ServletUtil;

@WebServlet("/carros/*")
public class CarroServelet extends HttpServlet {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private CarroService carroService = new CarroService();

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		String requestUri = req.getRequestURI();
		Long id = RegexUtil.matchId(requestUri);
		if (id != null) {
			// Informou o ID
			Carro carro;
			try {
				carro = carroService.getCarro(id);
				if (carro != null) {
					Gson gson = new GsonBuilder().setPrettyPrinting().create();
					String json = gson.toJson(carro);
					ServletUtil.writeJSON(resp, json);
				} else
					resp.sendError(404, "Carro n�o encontrado!");
			} catch (SQLException e) {
				e.printStackTrace();
			}

		} else {

			List<Carro> carros = carroService.getCarros();
			ListaCarros lista = new ListaCarros();
			lista.setCarros(carros);

			// Gera Json com GSON - Google
			Gson gson = new GsonBuilder().setPrettyPrinting().create();
			String json = gson.toJson(lista);
			// Escreve JSON na response do servlet com application/json
			ServletUtil.writeJSON(resp, json);
		}

		/*
		 * // Gera o XML String xml = JAXBUtil.toXML(lista); // Escreve o XML no
		 * response do Servelet com application/xml ServletUtil.writeXML(resp,
		 * xml);
		 */

		/*
		 * //Gera JSON com JABX e Jettison String json = JAXBUtil.toJSON(lista);
		 * // Escreve o JSON no response do Servelet com application/json
		 * ServletUtil.writeJSON(resp, json);
		 */

	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		try {
			// Cria o carro
			Carro carro = getCarroFromRequest(req);
			// salva o carro
			carroService.save(carro);
			// Escreve o JSON do novo carro
			Gson gson = new GsonBuilder().setPrettyPrinting().create();
			String json = gson.toJson(carro);
			ServletUtil.writeJSON(resp, json);

		} catch (NumberFormatException | SQLException e) {
			e.printStackTrace();
		}

	}

	private Carro getCarroFromRequest(HttpServletRequest req) throws NumberFormatException, SQLException {
		Carro c = new Carro();
		String id = req.getParameter("id");
		if (id != null) {
			// Se informou o ID busca o objeto no database;
			c = carroService.getCarro(Long.parseLong(id));
		}
		c.setNome(req.getParameter(Carro.NOME));
		c.setDesc(req.getParameter(Carro.DESC));
		c.setUrlFoto(req.getParameter(Carro.URL_FOTO));
		c.setUrlVideo(req.getParameter(Carro.URL_VIDEO));
		c.setLatitude(req.getParameter(Carro.LATITUDE));
		c.setLongitude(req.getParameter(Carro.LONGITUDE));
		c.setTipo(req.getParameter(Carro.TIPO));
		return c;
	}

	@Override
	protected void doDelete(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		String requestUri = req.getRequestURI();
		Long id = RegexUtil.matchId(requestUri);
		if (id != null) {
			// Informou o ID
			boolean excluido;
			try {
				excluido = carroService.delete(id);
				// Escreve o JSON da resposta
				if (excluido) {
					Response r = Response.OK("Carro excluido com sucesso!");
					Gson gson = new GsonBuilder().setPrettyPrinting().create();
					String json = gson.toJson(r);
					ServletUtil.writeJSON(resp, json);
				} else {
					Response r = Response.Error("Carro n�o encontrado para exclus�o!");
					Gson gson = new GsonBuilder().setPrettyPrinting().create();
					String json = gson.toJson(r);
					ServletUtil.writeJSON(resp, json);
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		} else {
			Response r = Response.Error("URL Inv�lida!");
			Gson gson = new GsonBuilder().setPrettyPrinting().create();
			String json = gson.toJson(r);
			ServletUtil.writeJSON(resp, json);
		}

	}
}
